steps to run the app
========================
1.) install node js
2.) exract the given zip file and extract the application
3.) go to the root of the application
4.) run npm start from command line
5.) type localhost:3000 on the browser to open the application
